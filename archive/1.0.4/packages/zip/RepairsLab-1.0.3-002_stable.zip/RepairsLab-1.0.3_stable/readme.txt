
            ===================================================
            =           Running RepairsLab 1.0.1a             =
            ===================================================
			
Running RepairsLab 1.0.1a requires the Java 2 Standard Edition Runtime
Environment (JRE) version 5.0 or later.

(1) Download and Install the J2SE Runtime Environment (JRE)

(1.1) Download the Java 2 Standard Edition Runtime Environment (JRE),
      release version 5.0 or later, from http://java.sun.com/j2se.

(1.2) Install the JRE according to the instructions included with the
      release.
(1.3) Set PATH environment variable as default java virtual machine


(2) Download and Install the RepairsLab Binary Distribution

(2.1) Download a binary distribution of RepairsLab from:

      http://repairslab.sourceforge.net/

(2.2) Unpack the binary distribution into a convenient location so that the
      distribution resides in its own directory (conventionally named
      "RepairsLab-[version]").


(3) Start Up RepairsLab

(3.1) RepairsLab can be started by executing the following commands:

      RepairsLab-[version]\RepairsLab.bat          (Windows)

      RepairsLab-[version]/RepairsLab.sh           (Unix)